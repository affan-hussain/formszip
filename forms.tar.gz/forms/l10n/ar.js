OC.L10N.register(
    "forms",
    {
    "Group" : "الفريق",
    "Title" : "العنوان",
    "Access" : "النفاذ",
    "Owner" : "المالك",
    "Error, while copying link to clipboard" : "خطأ أثناء نسخ الرابط إلى الحافظة",
    "Add Answer" : "إضافة إجابة",
    "Share with" : "شارك مع",
    "Description" : "الوصف",
    "Add Question" : "إضافة سؤال",
    "Done" : "تم",
    "New" : "جديد"
},
"nplurals=6; plural=n==0 ? 0 : n==1 ? 1 : n==2 ? 2 : n%100>=3 && n%100<=10 ? 3 : n%100>=11 && n%100<=99 ? 4 : 5;");
